# Tutorial — subir a landing no GitHub e Vercel

## O que vai neste pacote
- `index.html`
- `assets/logo.png`
- `assets/print1.jpeg`
- `assets/print2.jpeg`
- `assets/print3.jpeg`
- `assets/video-poster.png`
- `assets/video.mp4` **(você precisa colocar o vídeo real aqui)**

---

## Passo 1 — editar o link da Ticto
Abra o arquivo `index.html`.

Procure por:

```html
https://pay.ticto.com/SEU-LINK-AQUI
```

Troque por seu link real da Ticto em todos os lugares.

---

## Passo 2 — colocar o vídeo real
Dentro da pasta `assets`, coloque seu vídeo com este nome exato:

```text
video.mp4
```

Se não colocar, a página ainda abre por causa do poster, mas o vídeo não vai tocar.

---

## Passo 3 — criar repositório no GitHub
1. Entre no GitHub.
2. Clique em **New repository**.
3. Nome sugerido:

```text
nanonicoins-landing
```

4. Deixe como público ou privado.
5. Clique em **Create repository**.

---

## Passo 4 — subir os arquivos no GitHub sem instalar nada
### Opção mais fácil
1. Na página do repositório, clique em **uploading an existing file**.
2. Arraste **todos os arquivos da pasta** `nanonicoins_landing_final`.
3. Espere carregar.
4. Clique em **Commit changes**.

Importante: a estrutura precisa ficar assim no GitHub:

```text
/index.html
/assets/logo.png
/assets/print1.jpeg
/assets/print2.jpeg
/assets/print3.jpeg
/assets/video-poster.png
/assets/video.mp4
```

---

## Passo 5 — subir na Vercel
1. Entre na Vercel.
2. Clique em **Add New...** → **Project**.
3. Conecte sua conta GitHub, se ainda não estiver conectada.
4. Escolha o repositório `nanonicoins-landing`.
5. Clique em **Deploy**.

Como é HTML puro, a Vercel normalmente detecta sem precisar configurar nada.

---

## Passo 6 — testar
Quando a Vercel terminar, ela vai te dar um link parecido com:

```text
https://nanonicoins-landing.vercel.app
```

Teste:
- no PC
- no celular
- clique em todos os botões
- veja se o vídeo abre
- veja se o link da Ticto está certo

---

## Passo 7 — domínio próprio (opcional)
Se quiser usar domínio próprio depois:
1. Na Vercel, abra o projeto.
2. Vá em **Settings**.
3. Clique em **Domains**.
4. Adicione seu domínio.

---

## O que eu recomendo fazer antes de subir
- trocar o link da Ticto
- colocar o vídeo real do bot
- testar a página abrindo o `index.html` no navegador

---

## Como testar sem instalar nada
No Windows:
1. Extraia a pasta.
2. Dê dois cliques em `index.html`.
3. A página abre no navegador.

Se o vídeo não tocar localmente, sobe para a Vercel que normalmente funciona melhor no ambiente online.
